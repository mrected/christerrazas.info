		<?php doyle_Footer(); ?>
	</div><!-- #wrap -->
	<?php wp_footer(); ?>
</body>